
# Flashcard App (con Flask + Ollama llama3)

Esta aplicación permite generar tarjetas educativas (flashcards) usando un modelo de lenguaje local (`llama3`) a través de Ollama.

---

## 🧩 Requisitos previos

- Python 3.8 o superior
- `pip` instalado
- Ollama instalado y ejecutando el modelo `llama3`

Puedes descargar Ollama desde: https://ollama.com

Luego ejecuta:

```bash
ollama run llama3
```

---

## 🛠️ Instalación

### 1. Descomprime el archivo ZIP
Descomprime `flashcard_app.zip` en una carpeta de tu preferencia.

### 2. Instala dependencias de Python
Abre una terminal en la carpeta y ejecuta:

```bash
pip install flask requests
```

### 3. Ejecuta el backend (Flask)

```bash
python app.py
```

Esto iniciará el backend en [http://127.0.0.1:5000](http://127.0.0.1:5000)

---

## 🌐 Ejecuta el Frontend

Abre el archivo `index.html` con tu navegador (doble clic o clic derecho > abrir con...).

1. Escribe un tema, por ejemplo: `animales de la granja`
2. Haz clic en **"Generar Flashcards"** y espera unos segundos

---

## 🧪 Notas adicionales

- Asegúrate de que Ollama esté corriendo antes de probar el frontend.
- Si tu navegador bloquea CORS, puedes abrir el HTML desde un pequeño servidor local:

```bash
python -m http.server 8000
```

Luego abre [http://localhost:8000/index.html](http://localhost:8000/index.html)
